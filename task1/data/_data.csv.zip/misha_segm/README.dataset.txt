# hahaton_segm > 2024-07-06 2:32am
https://universe.roboflow.com/hahaton-qtqvo/hahaton_segm

Provided by a Roboflow user
License: CC BY 4.0

