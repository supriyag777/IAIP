# 1 > 2024-07-06 3:32am
https://universe.roboflow.com/1-v8voz/1-we6el

Provided by a Roboflow user
License: CC BY 4.0

